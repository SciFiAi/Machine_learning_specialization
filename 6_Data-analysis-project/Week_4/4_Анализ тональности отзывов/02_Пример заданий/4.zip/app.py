from flask import Flask, render_template, request
from classifier import IClassifier

app = Flask(__name__)


sentiment_classifier = IClassifier()

@app.route('/sentiment-demo', methods=["POST", "GET"])
def index_page(text="", prediction=""):
    if request.method == "POST":
        text = request.form["text"]
        prediction = sentiment_classifier.get_prediction(text)
        
    return render_template(
        'template.html', 
        text=text, 
        prediction=prediction
    )

if __name__ == '__main__':
    app.run(debug=True)