import pickle
import os
from sklearn.pipeline import Pipeline
from text_preprocessor import TextPreprocessor


class IClassifier:
    def __init__(self):
        with open(os.path.join('data', 'estimator.pkl'), 'rb') as f:
            estimator = pickle.load(f)
            self.classifier = Pipeline([
                ('text_preprocessor', TextPreprocessor()), 
                ('estimator', estimator)
            ])
            self.classes = {0: 'Negative', 1: 'Positive', -1: 'Prediction error'}
        
    def get_prediction(self, text):
        try:
            pred = self.classifier.predict([text])
            confidence = self.classifier.predict_proba([text]).max(axis=1)[0]
        except:
            return -1
        
        return f'{self.classes[pred[0]]} ({100 * confidence:.0f}% confident).'