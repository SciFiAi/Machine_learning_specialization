import spacy
import re
import numpy as np


nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])

def preprocess(text):
    text = re.sub(r"(\b\w+) (\w?)'(\w+)", r"\1\2'\3", text)
    text = re.sub(r"\bdont\b", "don't", text)
    text = re.sub(r"\bn't\b", "not", text)
    doc = nlp(text)
    text = ' '.join([token.lemma_ for token in doc])
    return text

class TextPreprocessor:
    def __init__(self):
        self.preprocess = np.vectorize(preprocess)
        
    def fit(self, X, y):
        return self
    
    def transform(self, X):
        return self.preprocess(X)