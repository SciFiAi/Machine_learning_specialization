from classification_demo.web_server import WebServer

web_server = WebServer(retrain=False, porter=True)
web_server.run(debug=False)
