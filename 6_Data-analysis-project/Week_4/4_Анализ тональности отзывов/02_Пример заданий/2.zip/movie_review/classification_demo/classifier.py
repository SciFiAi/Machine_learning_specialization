import pickle
import os
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from nltk.corpus import movie_reviews
from nltk.stem import PorterStemmer
from nltk import word_tokenize

class Classifier:

    __prediction_map = {
        1: ('positive', 'green'),
        0: ('negative', 'red')
    }

    __porter = None

    def __init__(self, logger, retrain=False, porter=True) -> None:
        self.__logger = logger
        self.__model_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'classification_model.pkl'
        )
        self.__model_cache = None
        if retrain:
            try:
                os.remove(self.__model_file)
            except FileNotFoundError:
                pass
        if porter:
            Classifier.__porter = PorterStemmer()
        self.__load_model()

    def get_prediction_message(self, text):
        pre_processed = self.__porter_stem(text) if Classifier.__porter is not None else text
        prediction = self.__model.predict([pre_processed])
        return Classifier.__prediction_map[prediction[0]]

    @property
    def __model(self):
        if not self.__model_cache:
            self.__load_model()
        return self.__model_cache

    def __load_model(self):
        if not os.path.isfile(self.__model_file):
            self.__train()
        with open(self.__model_file, 'rb') as model_file:
            model = pickle.load(model_file)
        self.__model_cache = model

    def __train(self):
        df = self.__get_data_frame()
        if self.__porter is not None:
            df.text = df.text.apply(self.__porter_stem)

        model = Pipeline([
            ('vectorizer', CountVectorizer()),
            ('classifier', LogisticRegression(random_state=42))
        ])
        model.fit(df.text, df.label)
        with open(self.__model_file, 'wb') as model_file:
            pickle.dump(model, model_file)

    def __get_data_frame(self):
        def get_label(fid):
            raw_class = movie_reviews.categories(fileids=[fid])
            if raw_class == ['pos']:
                return 1
            elif raw_class == ['neg']:
                return 0
            else:
                raise RuntimeError('unknown class')

        fileids = movie_reviews.fileids()
        df = pd.DataFrame({
            'fileid': fileids
        })
        df['text'] = df.fileid.apply(lambda fid: movie_reviews.raw(fileids=[fid]))
        df['label'] = df.fileid.apply(get_label)
        return df

    def __porter_stem(self, text):
        tokens = word_tokenize(text)
        return ' '.join([Classifier.__porter.stem(t) for t in tokens])
