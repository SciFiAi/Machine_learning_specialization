import joblib

class SentimentClassifier(object):

    def __init__(self):

        self.model = joblib.load(open('SentimentClassifier.pkl', 'rb'))

        self.classes_dict = {0: "отрицательная", 1: "положительная"}

    def predict_text(self, text):
        return self.model.predict([text])[0]

    def get_prediction_message(self, text):
        prediction = self.predict_text(text)
        return self.classes_dict[prediction]

