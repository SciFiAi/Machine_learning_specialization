from sentiment_classifier import SentimentClassifier
from MySentimentClassifier import MySentimentClassifier

clf = SentimentClassifier()

pred = clf.get_prediction_message("Ужасный телефон, не покупайте, глючит, тормозит, никому не рекомендую!")

print(pred)
