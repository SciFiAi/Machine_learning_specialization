from sentiment_classifier import SentimentClassifier
from flask import Flask, render_template, request
app = Flask(__name__)
from MySentimentClassifier import MySentimentClassifier

classifier = SentimentClassifier()

@app.route("/sentiment-demo", methods = ["POST", "GET"])
def index_page(text = "", prediction_message = ""):
    if request.method == "POST":
        text = request.form["text"]
        prediction_message = classifier.get_prediction_message(text)
        with open("ydf_demo_logs.txt", "a") as logfile:
            logfile.write("Request: \"%s\", Response: \"%s\"\n" % (text, prediction_message))
    
    return render_template('hello.html', text = text, prediction_message = prediction_message)


if __name__ == "__main__":
    app.run(host = '127.0.0.1', port = 8080, debug = False)
