# Анализ тональности отзывов

Для запуска требуется Python 3 с установленными модулями:
* `sklearn`
* `joblib`
* `flask`
* `nltk`

Запуск теста классификатора:
```bash
python classifier_test.py
```

Запуск веб-приложения классификатора:
```bash
python demo.py
```

![Sentiment Demo](screenshots/sentiment-demo-0.png)

После запуска приложение будет доступно по адресу [http://localhost:8080/sentiment-demo](localhost:8080/sentiment-demo).

![Sentiment Demo](screenshots/sentiment-demo-1.png)

Для использования классификатора введите в поле текст отзыва на русском языке и нажмите "Оценить":

![Sentiment Demo](screenshots/sentiment-demo-2.png)

Логи приложения записываются в файл `ydf_demo_logs.txt`.