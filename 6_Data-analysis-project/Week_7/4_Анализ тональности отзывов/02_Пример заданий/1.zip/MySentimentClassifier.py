import re
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import TfidfVectorizer

class MySentimentClassifier:

    def __init__(self):
        
        self.pipeline = Pipeline([
            ("vectorizer", TfidfVectorizer()), 
            ("classifier", LinearSVC())
        ])

    def fit(self, X, y):
        self.pipeline.fit(X, y)
            
    def predict(self, X):
        return self.pipeline.predict(X)
    