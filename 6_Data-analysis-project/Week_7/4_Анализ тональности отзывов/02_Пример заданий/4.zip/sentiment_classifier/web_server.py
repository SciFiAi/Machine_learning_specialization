from flask import Flask, render_template, request
import logging
from sentiment_classifier.classifier import Classifier

app = Flask(__name__)

class WebServer:

    __classifier = None
    __logger = None

    def __init__(self, retrain=False) -> None:
        self.__logfile = open('sentiment_classifier.log', 'a')
        logging.basicConfig(filename='sentiment_classifier.log',
                            format = "%(asctime)s [%(levelname)s]: %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S", level = logging.DEBUG)
        WebServer.__logger = logging.getLogger(__name__)
        WebServer.__classifier = Classifier(WebServer.__logger, retrain)

    def run(self, debug=True):
        global app
        print('server launching at: http://localhost:5000/sentiment-demo')
        app.run(debug=debug)

    @app.route("/sentiment-demo", methods=["POST", "GET"])
    def index_page(text="", prediction_message=""):
        if request.method == "POST":
            text = request.form["text"]
            print(text)
            WebServer.__logger.info(text)
            prediction_message, color = WebServer.__classifier.get_prediction_message(text)
            print(prediction_message)
            WebServer.__logger.info(prediction_message)
            return render_template('hello.html', text=text, prediction_message=prediction_message, color=color)
        else:
            return render_template('hello.html', text='', prediction_message='', color='white') 

    def __del__(self):
        self.__logfile.close()
