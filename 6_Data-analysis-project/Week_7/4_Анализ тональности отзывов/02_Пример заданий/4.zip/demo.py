from sentiment_classifier.web_server import WebServer

web_server = WebServer(retrain=False)
web_server.run(debug=False)
